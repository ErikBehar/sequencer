﻿using UnityEngine;

public class NguiBGPerSceneColorizer : MonoBehaviour 
{
    public string[] sceneName;
    public Color[] bgColor;
    public Color defaultColor;

    public UISprite targetBG;

    public SequencePlayer sequencePlayer;

    void Awake()
    {
        sequencePlayer.onChangeScene += onChangeScene;
    }

    void OnDestroy()
    {
        sequencePlayer.onChangeScene -= onChangeScene;
    }

    void onChangeScene( string newScene)
    {
        bool found = false;
        for (int i = 0; i < sceneName.Length; i++)
        {
            if (sceneName[i] == newScene)
            {
                targetBG.color = bgColor[i];
                found = true;
            }
        }

        if (!found)
            targetBG.color = defaultColor;
    }
}