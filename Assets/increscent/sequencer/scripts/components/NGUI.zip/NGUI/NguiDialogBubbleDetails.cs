﻿using UnityEngine;

public class NguiDialogBubbleDetails : MonoBehaviour
{
    public UILabel text;
    public UI2DSpriteAnimation bubbleAnimation;
    public UI2DSprite bubbleSprite;
    public TypewriterEffect typeWritter;

    public void clearAndDeactivate()
    {
        text.text = " ";
        if (bubbleAnimation != null)
            bubbleAnimation.ResetToBeginning();

        if ( typeWritter != null)
            typeWritter.ResetToBeginning();

        text.enabled = false;
        gameObject.SetActive(false);
    }
}