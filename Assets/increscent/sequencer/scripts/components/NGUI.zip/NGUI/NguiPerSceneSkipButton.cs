﻿using UnityEngine;

public class NguiPerSceneSkipButton : MonoBehaviour 
{
    public string[] sceneName;
    public bool[] enabledVal;

    public GameObject target;

    public SequencePlayer sequencePlayer;

    void Awake()
    {
        sequencePlayer.onChangeScene += onChangeScene;
    }

    void OnDestroy()
    {
        sequencePlayer.onChangeScene -= onChangeScene;
    }

    void onChangeScene( string newScene)
    {
        bool found = false;
        for (int i = 0; i < sceneName.Length; i++)
        {
            if (sceneName[i] == newScene)
            {
                target.SetActive(enabledVal[i]);
                found = true;
            }
        }

        if (!found)
            target.SetActive(true);
    }
}