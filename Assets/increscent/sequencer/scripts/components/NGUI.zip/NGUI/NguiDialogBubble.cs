﻿using UnityEngine;
using System;
using DG.Tweening;
using System.Collections.Generic;

public class NguiDialogBubble : DialogControllerBase
{
    public NguiDialogBubbleDetails speechBubbleLeft;
    public NguiDialogBubbleDetails speechBubbleRight;
    public NguiDialogBubbleDetails narratorBubble;

    NguiDialogBubbleDetails speechBubbleLeft2;
    NguiDialogBubbleDetails speechBubbleRight2;
    NguiDialogBubbleDetails narratorBubble2;

    public Transform centerPos;
    public Transform leftPos;
    public Transform rightPos;

    public Transform outLeftPos;
    public Transform outRightPos;
    public Transform outBottomPos;

    public Vector3 centerPosVec;
    public Vector3 leftPosVec;
    public Vector3 rightPosVec;

    public bool useBubbleUpdate = false;

    public bool doChopping = false;
    public int textLineSize = 30;

    public GameObject leftBubbleEdge;
    public float leftBubbleOriginalDifference;

    public GameObject rightBubbleEdge;
    public float rightBubbleOriginalDifference;

    bool shown = false;

    NguiDialogBubbleDetails previousBubble;
    NguiDialogBubbleDetails currentBubble;
    Vector3 lastTweenPosition;
    Vector3 lastOutsidePosition;

    public float showTextDelay = 0f;
    public bool tweenFromOutside = false;
    Tweener tween;
    public float tweenTime = .75f;

//    bool isSameBubble = false;

    public bool hideDialogAutomaticallyOnForward = true;

    List<NguiDialogBubbleDetails> bubbleList = new List<NguiDialogBubbleDetails> ();

    public string[] characterName;
    public Color[] bubbleColor;
    public Color[] textColor;

    Dictionary<string,Color[]> charToColor = new Dictionary<string,Color[]>();

    void Awake()
    {
        for (int i = 0; i < characterName.Length; i++)
        {
            charToColor.Add(characterName[i], new Color[]{bubbleColor[i], textColor[i]});
        }

        if (useBubbleUpdate)
        {
            leftBubbleOriginalDifference = (leftBubbleEdge.transform.position - speechBubbleLeft.transform.position).x;
            rightBubbleOriginalDifference = (rightBubbleEdge.transform.position - speechBubbleRight.transform.position).x;
        }

        speechBubbleLeft2 = ((GameObject)Instantiate( speechBubbleLeft.gameObject)).GetComponent<NguiDialogBubbleDetails>();
        speechBubbleLeft2.transform.parent = speechBubbleLeft.transform.parent;
        speechBubbleLeft2.transform.localScale = speechBubbleLeft.transform.localScale;

        speechBubbleRight2 = ((GameObject)Instantiate( speechBubbleRight.gameObject)).GetComponent<NguiDialogBubbleDetails>();
        speechBubbleRight2.transform.parent = speechBubbleRight.transform.parent;
        speechBubbleRight2.transform.localScale = speechBubbleRight.transform.localScale;

        narratorBubble2 = ((GameObject)Instantiate( narratorBubble.gameObject)).GetComponent<NguiDialogBubbleDetails>();
        narratorBubble2.transform.parent = narratorBubble.transform.parent;
        narratorBubble2.transform.localScale = narratorBubble.transform.localScale;

        bubbleList.Add(speechBubbleLeft);
        bubbleList.Add(speechBubbleLeft2);
        bubbleList.Add(speechBubbleRight);
        bubbleList.Add(speechBubbleRight2);
        bubbleList.Add(narratorBubble);
        bubbleList.Add(narratorBubble2);

        hideDialog();
    }

    void OnEnable()
    {
        hideDialog();
    }

    override public void showDialog(string text, GameObject charspeaker, float xOffset)
    {
        CancelInvoke();
        if ( tween != null)
            tween.Kill(true);

        shown = true;

        if ( doChopping)
            text = chopTextIntoPieces(textLineSize, parseForCarriageReturns(text));

        previousBubble = currentBubble;

        if (previousBubble != null)
            previousBubble.GetComponent<UIPanel>().depth -= 1;

//        isSameBubble = false;
        if (charspeaker.transform.localPosition.x > 1)
        {            
            if (currentBubble == speechBubbleRight)
            {
//                isSameBubble = true;
                currentBubble = speechBubbleRight2;
            }
            else if (currentBubble == speechBubbleRight2)
            {
//                isSameBubble = true;
                currentBubble = speechBubbleRight;
            }
            else
                currentBubble = speechBubbleRight;

            lastTweenPosition = rightPos.position + new Vector3(xOffset, 0, 0);
            lastOutsidePosition = outRightPos.position;
        } 
        else if (charspeaker.transform.localPosition.x < -1)
        { 
            if (currentBubble == speechBubbleLeft)
            {
//                isSameBubble = true;
                currentBubble = speechBubbleLeft2;
            }
            else if (currentBubble == speechBubbleLeft2)
            {
//                isSameBubble = true;
                currentBubble = speechBubbleLeft;
            }
            else
                currentBubble = speechBubbleLeft;

            lastTweenPosition = leftPos.position + new Vector3(xOffset, 0, 0);
            lastOutsidePosition = outLeftPos.position;
        }
        else //center
        {
            if (currentBubble == narratorBubble)
            {
//                isSameBubble = true;
                currentBubble = narratorBubble2;
            }
            else if (currentBubble == narratorBubble2)
            {
//                isSameBubble = true;
                currentBubble = narratorBubble;
            }
            else
                currentBubble = narratorBubble;
            
            lastTweenPosition = centerPos.position + new Vector3(xOffset, 0, 0);
            lastOutsidePosition = outBottomPos.position;
        }

        //all bubbles
        currentBubble.GetComponent<UIPanel>().depth += 1;

        currentBubble.text.text = text;
        currentBubble.bubbleAnimation.Play(); 
        currentBubble.gameObject.SetActive(true);

        if (!tweenFromOutside)
        {
            currentBubble.transform.position = lastTweenPosition;
            Invoke( "showTextAfterInitialDelay", showTextDelay);
            previousBubble.clearAndDeactivate();
        }
        else
        {
            currentBubble.transform.position = lastOutsidePosition;
            tween = DOTween.To(() => currentBubble.transform.position, x => currentBubble.transform.position = x, lastTweenPosition, tweenTime).OnComplete( onTweenComplete );
        }

        if (charToColor.ContainsKey(charspeaker.name))
        {
            currentBubble.bubbleSprite.color = charToColor[charspeaker.name][0];
            currentBubble.text.color = charToColor[charspeaker.name][1];
        }
    }

    void onTweenComplete()
    {
        Invoke( "showTextAfterInitialDelay", showTextDelay);

        previousBubble.clearAndDeactivate();
    }
        
    public void showTextAfterInitialDelay()
    {
        if (currentBubble.typeWritter != null && currentBubble.typeWritter.enabled)
            currentBubble.typeWritter.ResetToBeginning();

        currentBubble.text.enabled = true;
    }

    public string parseForCarriageReturns(string text)
    {
        return text.Replace("\\n", Environment.NewLine);
    }

    public string chopTextIntoPieces(int size, string originalText)
    {
        string[] temp = originalText.Split(new string[]
        {
            " ",
            Environment.NewLine
        }, StringSplitOptions.None);
        
        int newSize = 0;
        string finalString = "";
        foreach (string piece in temp)
        {
            newSize += piece.Length;
            if (newSize > size)
            {
                finalString += Environment.NewLine + piece;
                newSize = 0;
            } 
            else
                finalString += " " + piece;
        }
        return finalString;
    }

    override public void onForward()
    {
        if (hideDialogAutomaticallyOnForward)
        {
            hideDialog();
        }

        //Do nothing ?
    }

    //hides ALL dialogs 
    override public void hideDialog()
    {
        shown = false;

        for (int i = 0; i < bubbleList.Count; i++)
            bubbleList[i].clearAndDeactivate();
    }

    void FixedUpdate()
    {
        if (shown && useBubbleUpdate)
        {
            float newdifference = leftBubbleOriginalDifference - (leftBubbleEdge.transform.position - leftPosVec).x; 
            if (Mathf.Abs(newdifference) > .03f)
                speechBubbleLeft.gameObject.transform.position = new Vector3(Mathf.Lerp(speechBubbleLeft.gameObject.transform.position.x, speechBubbleLeft.gameObject.transform.position.x + newdifference, .25f),
                                                                             leftPosVec.y, leftPosVec.z);

            newdifference = rightBubbleOriginalDifference - (rightBubbleEdge.transform.position - rightPosVec).x; 
            if (Mathf.Abs(newdifference) > .03f)
                speechBubbleRight.gameObject.transform.position = new Vector3(Mathf.Lerp(speechBubbleRight.gameObject.transform.position.x, speechBubbleRight.gameObject.transform.position.x + newdifference, .25f),
                                                                        rightPosVec.y, rightPosVec.z);
        }
    }

    override public bool dialogIsShown()
    {
        if (currentBubble.typeWritter != null && currentBubble.typeWritter.enabled)
            return !currentBubble.typeWritter.isActive;
        else
            return true;
    }

    override public void dialogForceComplete()
    {       
        if (currentBubble.typeWritter != null && currentBubble.typeWritter.enabled)
            currentBubble.typeWritter.Finish();
    }
}