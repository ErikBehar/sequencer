﻿using UnityEngine;
using System.Collections.Generic;

public class NguiChoiceButtons : ChoiceControllerBase
{
    public GameObject exampleButton;

    public UISprite topSprite;
    public UISprite centerSprite;
	public UISprite leftSprite;
	public UISprite rightSprite;

    List<ChoiceModel> currChoices;

    List<GameObject> buttons = new List<GameObject>();

    SequencePlayer currentPlayer;

	public bool layoutVertically = true;

    void Start()
    {
        exampleButton.SetActive(false);
    }

    override public void generateButtons(List<ChoiceModel> choices, SequencePlayer player)
    {
        currentPlayer = player;

        if (buttons.Count > 0)
        {
            cleanup();
        }

        currChoices = choices;

		float screenHeightHalf = topSprite.transform.localPosition.y - centerSprite.transform.localPosition.y;

		if (layoutVertically) 
		{
			for (int i = 0; i < choices.Count; i++) 
			{
				GameObject button = Instantiate(exampleButton);
				button.transform.FindChild ("Label").GetComponent<UILabel> ().text = choices [i].text;
				EventDelegate.Add (button.GetComponent<UIButton> ().onClick, onButtonClick);  
				button.transform.parent = exampleButton.transform.parent;
				button.transform.localPosition = new Vector3 (0f, (screenHeightHalf / (choices.Count + 1f)) * (i + 1f), 0f);
				button.transform.localScale = Vector3.one;
				button.SetActive (true);
				buttons.Add (button);
			}
		} 
		else //layout horizontally
		{
			float screenWidth = rightSprite.transform.localPosition.x - leftSprite.transform.localPosition.x;

			for (int i = 0; i < choices.Count; i++) 
			{
				GameObject button = Instantiate(exampleButton);
				button.transform.FindChild ("Label").GetComponent<UILabel> ().text = choices [i].text;
				EventDelegate.Add (button.GetComponent<UIButton> ().onClick, onButtonClick);  
				button.transform.parent = exampleButton.transform.parent;
				button.transform.localPosition = new Vector3 ( leftSprite.transform.localPosition.x + ((i+1f) * (screenWidth/(choices.Count+1))), (screenHeightHalf / 2f), 0f);
				button.transform.localScale = Vector3.one;
				button.SetActive (true);
				buttons.Add (button);
			}
		}
    }

    void onButtonClick()
    {
        foreach (ChoiceModel model in currChoices)
        {
            if (model.text == UIButton.current.gameObject.transform.FindChild("Label").GetComponent<UILabel>().text)
            {
                cleanup();
                currentPlayer.jumpToScene(model.sceneNameToJump, model.sceneCommandIndexToJump);
                break;
            }
        }
    }

    override public void cleanup()
    {
        foreach (GameObject button in buttons)
        {
            EventDelegate.Remove(button.GetComponent<UIButton>().onClick, onButtonClick);
            Destroy(button);
        }

        buttons = new List<GameObject>(); 
    }
}